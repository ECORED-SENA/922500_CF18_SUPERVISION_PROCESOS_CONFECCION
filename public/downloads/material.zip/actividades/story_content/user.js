function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5WEBaK5I9me":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

